# Omnichannel Social CX Platform — System Architecture
**Phase 1 of 16 — Architecture & Data Model**

---

## 1. Design Principles

1. **Multi-tenant from day one.** Every row, every cache key, every search index is partitioned by `workspaceId`. Retrofitting multi-tenancy later is far more expensive than building it in now.
2. **Channel adapters are plugins, not core code.** Adding TikTok Comments in month 8 must not require touching the inbox, routing, or AI services. New channels implement one interface and register themselves.
3. **Ingestion is decoupled from processing.** A webhook spike from Meta or a WhatsApp burst must never block the API or drop messages. Everything inbound lands on a queue first.
4. **AI is a gateway, not a dependency.** The rest of the system calls one internal `AI Orchestration Service`. Swapping OpenAI for Claude, or adding a local Llama fallback, happens in one place.
5. **Read and write paths scale independently.** Agents reading the inbox (high volume, low latency) should not be bottlenecked by analytics aggregation (high compute, can be async).
6. **Everything real-time is additive.** If Socket.IO/Redis pub-sub is down, the system still works via polling/refresh — it degrades, it doesn't break.

---

## 2. High-Level Architecture

```mermaid
flowchart TB
    subgraph External["External Channels"]
        FB[Facebook Messenger/Comments]
        IG[Instagram DM/Comments]
        TW[X/Twitter]
        WA[WhatsApp Business API]
        TT[TikTok]
        LI[LinkedIn]
        YT[YouTube Comments]
        TG[Telegram]
        EM[Email - SMTP/IMAP]
        SMS[SMS - Twilio]
        LC[Live Chat Widget SDK]
    end

    subgraph Edge["Edge Layer"]
        GW[API Gateway / BFF<br/>Next.js API routes + NestJS Gateway]
        WH[Webhook Receiver Service]
        LCWS[Live Chat WS Endpoint]
    end

    subgraph Queue["Async Backbone (Redis + BullMQ)"]
        QIN[inbound-messages queue]
        QOUT[outbound-messages queue]
        QAI[ai-jobs queue]
        QAUTO[automation-jobs queue]
        QIDX[search-index queue]
        QNOTIF[notification queue]
    end

    subgraph Core["Core Domain Services (NestJS, modular monolith → extractable)"]
        CHAN[Channel Adapter Service<br/>one adapter per platform]
        IDENT[Customer Identity<br/>Resolution Service]
        CONV[Conversation / Inbox Service]
        ROUTE[Routing Engine]
        AUTOM[Automation Engine]
        AI[AI Orchestration Service]
        KB[Knowledge Base Service]
        TEAM[Team & Permissions Service]
        NOTIF[Notification Service]
        ANALYTICS[Analytics & Reporting Service]
        SEARCH[Search Indexer]
    end

    subgraph Data["Data Layer"]
        PG[(PostgreSQL<br/>Prisma ORM)]
        REDIS[(Redis<br/>cache + queues + pubsub)]
        S3[(S3<br/>attachments/media)]
        ES[(Elasticsearch/Meilisearch)]
        CH[(ClickHouse or Postgres+TimescaleDB<br/>analytics event store - optional at scale)]
    end

    subgraph AIProviders["AI Providers"]
        OAI[OpenAI]
        CLD[Anthropic Claude]
        GEM[Google Gemini]
        LOCAL[Local LLM - Ollama/vLLM]
    end

    subgraph Realtime["Real-time Layer"]
        SOCK[Socket.IO Cluster<br/>Redis Adapter]
    end

    External -->|webhooks| WH
    External -->|widget events| LCWS
    WH --> QIN
    LCWS --> QIN
    QIN --> CHAN
    CHAN --> IDENT
    IDENT --> CONV
    CONV --> PG
    CONV --> ROUTE
    ROUTE --> TEAM
    CONV -.push.-> SOCK
    SOCK -.-> GW
    CONV --> QAI
    QAI --> AI
    AI --> OAIProviders
    AI --> OAI & CLD & GEM & LOCAL
    CONV --> QAUTO
    QAUTO --> AUTOM
    AUTOM --> ROUTE
    AUTOM --> NOTIF
    CONV --> QIDX
    QIDX --> SEARCH
    SEARCH --> ES
    CONV --> QOUT
    QOUT --> CHAN
    CHAN -->|reply via platform API| External
    NOTIF --> QNOTIF
    QNOTIF --> SOCK
    ANALYTICS --> PG
    ANALYTICS --> CH
    GW --> Core
    Core --> PG
    Core --> REDIS
    Core --> S3
```

**Deployment shape:** this is designed as a **modular monolith on NestJS** at launch (one deployable, internally organized into the domain modules above, each behind a clean interface), with the queue-based boundaries already in place so that any module (most likely `Channel Adapter Service` and `AI Orchestration Service`, the two with the spikiest independent load) can be **extracted into its own deployment** later without a rewrite — only a routing change. This avoids premature microservice overhead while keeping the exit ramps open. Re-evaluate extraction once a single module's load profile diverges significantly from the rest (see §8).

---

## 3. Core Services

### 3.1 Channel Adapter Service
The only part of the system that knows platform-specific details (Graph API, Twitter API v2, WhatsApp Cloud API, etc).

- **Interface every adapter implements:**
  ```ts
  interface ChannelAdapter {
    channel: ChannelType;
    verifyWebhook(req): boolean;
    normalizeInbound(rawPayload): NormalizedMessage;
    sendReply(msg: OutboundMessage): Promise<ProviderMessageId>;
    supportedActions: ('like' | 'react' | 'delete' | 'hide' | 'reply' | 'attachment')[];
    fetchCustomerProfile(providerId): Promise<PartialCustomer>;
  }
  ```
- Registered in a `ChannelAdapterRegistry` at boot. Adding a new channel = new folder implementing the interface + a DB row in `Channel` config — zero changes to `Conversation`, `Routing`, or `AI` services. This directly satisfies the "plug-and-play future integrations" requirement.
- Normalizes every inbound payload (DM, comment, mention, email, SMS) into one canonical `NormalizedMessage` shape before it ever touches the rest of the system. This is what makes a single unified inbox possible across 15 structurally different APIs.
- Rate-limit and credential management per workspace-per-channel (each workspace connects its own FB/IG/WA business accounts via OAuth).

### 3.2 Customer Identity Resolution Service
- Deduplicates/merges a customer across channels (same person DMs on FB, then emails, then WhatsApps).
- Deterministic matching first (verified email, verified phone, WhatsApp number), probabilistic/fuzzy matching second (name + platform + workspace behavioral signals), always with an agent-reviewable merge suggestion — **never silently auto-merge on fuzzy signals** for compliance/audit reasons.
- Maintains `CustomerIdentity` (the merged person) → many `CustomerChannelProfile` (one per platform handle).

### 3.3 Conversation / Inbox Service
- Owns `Conversation`, `Message`, `Ticket` state machines (open → assigned → waiting-on-customer → escalated → closed → reopened).
- Emits domain events (`conversation.created`, `message.received`, `sla.breached`, etc.) onto Redis pub-sub — every other service (routing, automation, notifications, analytics) reacts to these events rather than being called synchronously. This event-driven spine is what lets AI, automation, and analytics all "see" every conversation without coupling to the inbox's internals.

### 3.4 Routing Engine
- Rule evaluation engine (language, platform, VIP tier, keyword, sentiment, product, team, region, business hours, skill, load-based/overflow).
- Rules stored as structured JSON (evaluated by a small rules engine, not code-generated) so they're editable in the Admin UI without deploys.
- Consumes `conversation.created`/`message.received` events; on no-match, falls back to overflow queue.

### 3.5 Automation Engine
- Executes the visual workflow builder's saved graphs (trigger → condition → action nodes), stored as a DAG (JSON) per workspace.
- Same trigger vocabulary as Routing but broader action set (webhooks, Slack, email, ticket creation) — Routing is really a specialized, higher-priority subset of Automation and can share its execution runtime.

### 3.6 AI Orchestration Service
- Single internal API (`POST /internal/ai/complete`, `/ai/classify`, `/ai/summarize`, etc.) used by every other service — nothing else calls OpenAI/Claude/Gemini directly.
- Provider-agnostic prompt templates + a provider adapter per LLM (OpenAI, Claude, Gemini, local via Ollama/vLLM), selected per-workspace (cost/data-residency preference) with automatic fallback if a provider errors/rate-limits.
- Two execution modes:
  - **Sync, latency-sensitive** (reply suggestion while agent is typing) — direct call, short timeout, streamed.
  - **Async, batch** (auto-tagging, sentiment on every inbound message, QA scoring, coaching) — via `ai-jobs` queue, workers process in parallel, write results back to `Message`/`Conversation`.
- Every AI action is logged (`AiInvocation` table: prompt, model, tokens, latency, workspace) — required for cost tracking and audit/compliance.

### 3.7 Knowledge Base Service
- Internal articles + public help center content, versioned.
- Indexed into the same search cluster; `AI Orchestration Service` uses it as retrieval context (RAG) for reply suggestions and "suggested articles while typing."

### 3.8 Team & Permissions Service
- RBAC (Agent / Supervisor / Manager / Admin, each workspace-scoped), live monitoring feeds, whisper mode, and conversation takeover — implemented as elevated-permission actions on the same `Conversation` service, gated by policy checks, not a separate data model.

### 3.9 Notification Service
- Fans out real-time events to Socket.IO (in-app), and to email/push/webhook for offline delivery. One `notification` domain event in → many delivery channels out.

### 3.10 Analytics & Reporting Service
- Reads from Postgres for moderate volume; for high-cardinality event analytics (per-message sentiment trends, AI usage, response-time percentiles at scale) an append-only event table (Postgres + TimescaleDB extension, or ClickHouse once volume justifies it) avoids hammering the transactional DB with heavy aggregation queries.
- Pre-aggregates common dashboard queries into materialized views refreshed on a schedule, rather than computing FRT/SLA/CSAT live on every dashboard load.

### 3.11 Search Indexer
- Consumes the same domain events, writes into Meilisearch (recommended default — simpler ops, excellent typo-tolerant search, sufficient scale for most enterprise CX workloads) or Elasticsearch (if the org already runs an ELK stack or needs advanced aggregations). Both are supported behind one `SearchProvider` interface for the same plug-and-play reason as channels.

---

## 4. Key Data Flows

### 4.1 Inbound message (e.g. a WhatsApp message)
1. WhatsApp Cloud API calls the workspace's registered webhook → `Webhook Receiver` validates signature, immediately acks 200, pushes raw payload to `inbound-messages` queue. *(Ack-then-process is mandatory — providers disable webhooks that timeout or 5xx.)*
2. `Channel Adapter (WhatsApp)` worker picks it up, normalizes it, resolves/creates the `CustomerIdentity`.
3. `Conversation Service` finds-or-creates the `Conversation`, appends the `Message`, emits `message.received`.
4. In parallel, fan-out consumers react: `Routing Engine` (assign), `AI Orchestration` (sentiment/intent/auto-tag/spam-check, async), `Search Indexer` (index), `Notification Service` (alert assigned agent), `Automation Engine` (any matching workflows).
5. `Socket.IO` pushes the new message to any agent viewing that conversation/inbox in real time.

### 4.2 Outbound reply
1. Agent sends a reply in the UI → `Conversation Service` writes the `Message` (status `sending`) and enqueues on `outbound-messages`.
2. `Channel Adapter` worker calls the platform's send API, gets back a provider message ID, updates status to `sent`/`failed` with retry+backoff on transient failures.
3. Delivery/read receipts (where platforms support them, e.g. WhatsApp) arrive as another inbound webhook and update the same `Message` row.

---

## 5. Multi-Tenancy Model

- **Shared database, `workspaceId` on every table** (row-level isolation) is the default — cheapest to operate, easiest to migrate, sufficient isolation for the vast majority of enterprise CX tenants when combined with Postgres Row-Level Security policies as a hard backstop against app-layer bugs.
- **Schema-per-tenant or DB-per-tenant** is offered only as an Enterprise/regulated-industry tier (e.g. a customer with strict data-residency requirements), via the same Prisma schema deployed into an isolated database — not a different codebase.
- Every cache key, queue job, and search index document is namespaced by `workspaceId` for the same reason.

---

## 6. Real-Time Layer

- Socket.IO cluster behind the API gateway, using the **Redis adapter** so any gateway node can broadcast to a client connected on any other node — required once you run more than one instance.
- Clients join rooms: `workspace:{id}`, `conversation:{id}`, `agent:{id}` — events are scoped, not broadcast-all, to keep payloads small at scale.
- Presence (agent online/away/on-call) and typing indicators live in Redis with short TTLs, not Postgres — this is ephemeral, high-write data that doesn't belong in the durable store.

---

## 7. Security Architecture

- **AuthN:** Auth.js (Next.js side) or Keycloak (if the buyer needs enterprise SSO/SAML/OIDC out of the box) issuing short-lived JWTs + refresh tokens; MFA (TOTP) enforced per-workspace policy.
- **AuthZ:** RBAC evaluated at the NestJS guard layer on every request, plus Postgres Row-Level Security as defense-in-depth against `workspaceId` leakage bugs.
- **Audit log:** every state-changing action (reply sent, conversation reassigned, customer merged, permission changed, data exported) written to an append-only `AuditLog` table — required for SOC2 and for GDPR/POPIA accountability obligations.
- **Secrets:** channel OAuth tokens and API keys encrypted at rest (KMS-backed envelope encryption), never returned to the frontend.
- **PII handling:** customer data export/erasure endpoints (GDPR Art. 17 / POPIA equivalent), configurable data-retention policies per workspace.
- **Compliance posture:** SOC2-readiness means logging, access control, encryption-in-transit (TLS everywhere) and at-rest, and change management from day one — it's far cheaper to build this in than to retrofit it before an audit.

---

## 8. Scalability Notes

| Component | Scaling strategy |
|---|---|
| NestJS API/core services | Horizontal, stateless, behind a load balancer; scale on CPU/queue depth |
| Channel Adapter workers | Scale independently per-channel — WhatsApp volume and TikTok comment volume rarely spike together, so separate BullMQ queues let you scale each worker pool independently |
| AI Orchestration workers | Scale on `ai-jobs` queue depth; this is usually the most expensive and most latency-variable component — isolate it first if extracting a service |
| Postgres | Vertical scaling + read replicas for analytics/reporting reads; partition `Message`/`AuditLog` by month once volume justifies it |
| Redis | Cluster mode once queue+pubsub+cache load exceeds a single node |
| Search | Meilisearch/ES cluster, sharded by workspace at very large scale |
| Socket.IO | Horizontal with Redis adapter; sticky sessions at the load balancer |

**When to extract from the modular monolith:** Channel Adapters and AI Orchestration are the two candidates most likely to need independent scaling/deploy cadence early (spiky webhook traffic; expensive, variable-latency LLM calls). Extract them into separate deployables first, communicating over the same queues, once their load profile diverges meaningfully from the rest — the queue-based boundaries mean this is a deployment change, not a rewrite.

---

## 9. Why These Tradeoffs

- **Modular monolith over microservices at launch:** with one team building 15 channel integrations, a routing engine, an automation builder, and AI features simultaneously, the operational overhead of 10+ independently deployed services would slow delivery far more than it would help — and nothing here is designed in a way that blocks extraction later.
- **Queue-first ingestion over direct synchronous processing:** webhook providers (Meta, WhatsApp, TikTok) will disable your integration if you don't ack quickly and reliably; decoupling ingestion from processing is non-negotiable at this scope, not a nice-to-have.
- **Meilisearch as the default search recommendation over Elasticsearch:** lower operational burden, comparable relevance for support-ticket-style search; Elasticsearch remains fully supported behind the same interface for buyers who need it.

---

*Next: Phase 2 — full Prisma database schema (ERD) implementing every entity referenced above.*
